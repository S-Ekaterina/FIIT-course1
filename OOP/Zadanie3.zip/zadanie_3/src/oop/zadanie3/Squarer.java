package oop.zadanie3;

public class Squarer implements Function{
    private int x;

    public Squarer(){
        x = 0;
    }

    public Squarer(int x){
        this.x = x;
    }

    @Override
    public void setInput(int input) {
        x = input;
    }

    @Override
    public int getOutput(){
        return x*x;
    }
}

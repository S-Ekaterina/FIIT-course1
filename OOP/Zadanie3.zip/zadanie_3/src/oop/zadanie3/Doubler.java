package oop.zadanie3;

public class Doubler implements Function{
    private int x;

    public Doubler(){
        x = 0;
    }

    public Doubler(int x){
        this.x = x;
    }

    @Override
    public void setInput(int input) {
        x = input;
    }

    @Override
    public int getOutput(){
        return 2*x;
    }
}

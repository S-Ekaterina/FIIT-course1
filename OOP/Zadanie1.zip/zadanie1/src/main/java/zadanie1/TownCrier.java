package zadanie1;

public class TownCrier {
    private String text;
    private int value;

    public TownCrier(){
        this.value = 0;
    }

    public void setMessage(String message){
        this.text = message;
        this.value = 0;
    }
    public String announce(){
        this.value ++;
        return this.text;

    }
    public int getNumberOfLastMessageAnnounced(){
        return this.value;
    }
}

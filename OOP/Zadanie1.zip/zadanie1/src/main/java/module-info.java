module sample.zadanie1 {
    requires javafx.controls;
    requires javafx.fxml;


    opens zadanie1 to javafx.fxml;
    exports zadanie1;
}
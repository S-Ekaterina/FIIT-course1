package oop.zadanie2;

public class DayWeb extends AbstractWeb{
    String[] days = {
            "pondelok",
            "utorok",
            "streda",
            "stvrtok",
            "piatok",
            "sobota",
            "nedela"
    };

    public DayWeb(User[] users) {
        super(users);
    }


    @Override
    public Response getById(Request request) {
        if (authenticate(request)) {
            int id = request.getId();

            if (id > 0 && id <= days.length) {
                return new Response(true, days[id-1]);
            }
        }

        return new Response(false, "");
    }

    @Override
    public Response getAll(Request request) {
        if (authenticate(request)) {
            String str = String.join(", ", days);
            IO.println(str);
            return new Response(true, str);
        }
        return new Response(false, "");
    }
}

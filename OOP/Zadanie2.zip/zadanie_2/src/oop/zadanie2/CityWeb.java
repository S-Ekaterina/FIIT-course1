package oop.zadanie2;

public class CityWeb extends AbstractWeb {
    private String[] dat;

    public CityWeb(User[] users, String[] dat) {
        super(users);
        this.dat = dat;
    }

    @Override
    public Response getById(Request request) {
        if (authenticate(request)) {
            int id = request.getId();

            if (id >= 0 && id < dat.length) {
                return new Response(true, dat[id]);
            }
        }
        return new Response(false, "");
    }

    @Override
    public Response getAll(Request request) {
        if (authenticate(request)) {
            String str = String.join(", ", dat);
            IO.println(str);
            return new Response(true, str);
        }
        return new Response(false, "");
    }
}

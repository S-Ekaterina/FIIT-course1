package oop.zadanie2;

public class Main {

    public static void main(String[] args) {
        User[] users = {
                new User("1","1"),
                new User("2","2"),
                new User("3","3"),
                new User("4","4")
        };
        String[] dat = {
                "Bratislava",
                "Kosice",
                "Trnava"
        };
        CityWeb s = new CityWeb(users, dat);

        Request req = new Request("1", "1", 1);
        s.getAll(req);
        System.out.println(System.getProperty("java.version"));
    }
}

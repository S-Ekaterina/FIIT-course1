package oop.zadanie7;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class WarehouseLoader {

    public List<Product> loadProducts(String filename) throws InvalidProductFormatException {
        List<Product> products = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // parsovanie riadku ...
                if (line.trim().isEmpty()) {
                    continue;
                }
                String[] pars = line.split(",");
                for (int i = 0; i < pars.length; i++) {
                    pars[i] = pars[i].trim();
                }

                if (pars.length != 5) {
                    throw new InvalidProductFormatException("Nespravny pocet stlpcov: " + line);
                }

                Product product;
                try {
                    if (pars[0].equals("E")) {
                        product = new ElectronicProduct(pars[1], pars[2], Double.parseDouble(pars[3]), Integer.parseInt(pars[4]));
                    }

                    else if (pars[0].equals("P")) {
                        product = new PerishableProduct(pars[1], pars[2], Double.parseDouble(pars[3]), LocalDate.parse(pars[4]));
                    }

                    else {
                        throw new InvalidProductFormatException("Neznamy typ produktu: " + line);
                    }
                } catch (Exception e) {
                    throw new InvalidProductFormatException("Neplatny format: " + line);
                }

                products.add(product);

            }
        } catch (IOException e) {
            // spracovanie IO chyby
            e.printStackTrace();
        }
        Collections.sort(products);
        return products;
    }

    public void saveProducts(List<Product> products, String filename) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (Product p : products) {

                if(p instanceof ElectronicProduct) {
                    ElectronicProduct pe = (ElectronicProduct) p;
                    writer.write("E," +
                                    pe.getId() + "," +
                                    pe.getName() + "," +
                                    pe.getPrice() + "," +
                                    pe.getWarrantyMonths());
                }
                else if (p instanceof PerishableProduct) {
                    PerishableProduct pp = (PerishableProduct) p;
                    writer.write("P," +
                                    pp.getId() + "," +
                                    pp.getName() + "," +
                                    pp.getPrice() + "," +
                                    pp.getExpirationDate());
                }
                writer.newLine();


            }
        } catch (IOException e) {
            // spracovanie IO chyby
            e.printStackTrace();
        }
    }
}

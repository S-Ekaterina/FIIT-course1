package oop.zadanie7;

import java.util.*;

public class Warehouse {
    private Map<String, Product> products;

    public Warehouse() {
        this.products = new HashMap<>();
    }

    // Ak ID už existuje → chyba
    public void addProduct(Product p) throws ProductAlreadyExistsException {
        if (products.containsKey(p.getId())) {
            throw new ProductAlreadyExistsException("Product s ID '" + p.getId() + "' sa v sklade už nachádza.");
        }
        products.put(p.getId(), p);
    }

    // Ak ID neexistuje → chyba
    public void removeProduct(String id) throws ProductNotFoundException {
        if(!products.containsKey(id)) {
            throw new ProductNotFoundException("Product s ID '" + id + "' sa v sklade nenachádza.");
        }

        products.remove(id);
    }

    // Vráti produkt alebo null
    public Product getProduct(String id) {
        return products.get(id);
    }

    // Počet produktov v sklade
    public int getProductCount() {
        return products.size();
    }

    // Vráti List<Product> s cenou v rozsahu [min, max]
    public List<Product> findProductsByPriceRange(double min, double max) {
        List<Product> vysledok = new ArrayList<>();
        for (Product p : products.values()) {
            double price = p.getPrice();
            if (price >= min && price <= max) {
                vysledok.add(p);
            }
        }

        return vysledok;
    }

    // Vráti List<Product> zoradený vzostupne podľa ceny (odporúča sa použiť Comparator)
    public List<Product> getProductsSortedByPrice() {
        List<Product> vysledok = new ArrayList<>(products.values());
        vysledok.sort(Comparator.comparingDouble(Product::getPrice));
        return vysledok;
    }

    // Vráti List<Product> zoradený podľa compareTo() — teda podľa ID abecedne
    public List<Product> getProductsSortedById(){
        List<Product> vysledok = new ArrayList<>(products.values());
        vysledok.sort(Product::compareTo);
        return vysledok;
    }

    // Generická metóda – vráti len produkty daného typu (priklad dole v zadanii)
    public <T extends Product> List<T> getProductsByType(Class<T> type){
        List<T> vysledok = new ArrayList<>();
        for (Product p : products.values()) {
            if(type.isInstance(p)) {
                vysledok.add(type.cast(p));
            }
        }
        return vysledok;
    }

    // Vráti produkt s abecedne najmenším ID — používa compareTo() priamo v for cykle
    public Product findProductWithSmallestId(){
        Product vysledok = null;
        for (Product p : products.values()) {
            if(vysledok == null || p.compareTo(vysledok) < 0) {
                vysledok = p;
            }
        }
        return vysledok;
    }

    // Súčet cien všetkých produktov v sklade
    public double calculateTotalValue() {
        double vysledok = 0;
        for (Product p : products.values()) {
            vysledok += p.getPrice();
        }
        return vysledok;
    }
}

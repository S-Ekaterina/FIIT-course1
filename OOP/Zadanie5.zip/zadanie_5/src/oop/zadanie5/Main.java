package oop.zadanie5;

import java.util.ArrayList;
import java.util.List;

public class Main {
    static void main(String[] args) {
        /*
        IO.println("1 pripad:");
        Translator t = new Translator();

        // t.set("f", "ф");
        IO.println("Preklad slova f: " + t.translate("f"));
        IO.println("Mozem prelozit f? " + t.canTranslate("f"));
        IO.println("Pocet riadkov: " + t.getSize());

        IO.println("\n2 pripad:");

        Translator tr = new Translator();

        tr.set("f", "ф");
        IO.println("Preklad slova f: " + tr.translate("f"));
        IO.println("Mozem prelozit f? " + tr.canTranslate("f"));
        IO.println("Pocet riadkov: " + tr.getSize());

        IO.println("\n3 pripad:");

        Translator tra = new Translator();

        tra.set("f", "ф");
        tra.set("š", "ш");
        tra.set("č", "ч");
        tra.set("ž", "ж");
        IO.println("Preklad slova f: " + tra.translate("f"));
        IO.println("Preklad slova š: " + tra.translate("š"));
        IO.println("Mozem prelozit č? " + tra.canTranslate("č"));
        IO.println("Mozem prelozit ž? " + tra.canTranslate("ž"));
        IO.println("Pocet riadkov: " + tra.getSize());
        */

        IO.println("\nFonetický prepis slovenskej výslovnosti napísaný ruskými písmenami:");

        Translator tran = new Translator();
        // a á b c č d ď
        tran.set("a", "а");
        tran.set("á", "аа");
        tran.set("b", "б");
        tran.set("c", "ц");
        tran.set("č", "ч");
        tran.set("d", "д");
        tran.set("ď", "дь");
        // e é f g h ch
        tran.set("e", "э");
        tran.set("é", "ээ");
        tran.set("f", "ф");
        tran.set("g", "г");
        tran.set("h", "х");
        tran.set("ch", "х");
        // i í j k l ĺ ľ
        tran.set("i", "и");
        tran.set("í", "ии");
        tran.set("j", "й");
        tran.set("k", "к");
        tran.set("l", "л");
        tran.set("ĺ", "л");
        tran.set("ľ", "ль");
        // m n ň o ó ô
        tran.set("m", "м");
        tran.set("n", "н");
        tran.set("ň", "нь");
        tran.set("o", "о");
        tran.set("ó", "оо");
        tran.set("ô", "уо");
        // p q r ŕ s š
        tran.set("p", "п");
        tran.set("q", "ку");
        tran.set("r", "р");
        tran.set("ŕ", "рр");
        tran.set("s", "с");
        tran.set("š", "ш");
        // t ť u ú v w
        tran.set("t", "т");
        tran.set("ť", "ть");
        tran.set("u", "у");
        tran.set("ú", "уу");
        tran.set("v", "в");
        tran.set("w", "в");
        // x y ý z ž
        tran.set("x", "кс");
        tran.set("y", "ы");
        tran.set("ý", "ыы");
        tran.set("z", "з");
        tran.set("ž", "ж");
        // symboly
        tran.set(" ", " ");
        tran.set("(", "(");
        tran.set(")", ")");
        tran.set("0", "нула");
        tran.set("1", "една");
        tran.set("2", "два");
        tran.set("3", "три");
        tran.set("4", "штырьи");
        tran.set("5", "пэть");
        tran.set("6", "шесть");
        tran.set("7", "седем");
        tran.set("8", "осем");
        tran.set("9", "девять");



        List<String> list = new ArrayList<>();
        list.add("Slovenská technická univerzita v bratislave (STU)");
        list.add("Fakulta elektrotechniky a informatiky");
        list.add("Aplikovaná informatika");
        list.add("Objektovo orientované programovanie");
        list.add("Zadanie 5");

        String result;
        char c, c1;
        for (String l : list) {
            result = "";
            for (int i = 0; i < l.length(); i++) {
                c = Character.toLowerCase(l.charAt(i));
                if (i+1 == l.length()) {
                    if (Character.isLowerCase(l.charAt(i))) {
                        result = result + tran.translate(String.valueOf(c));
                    }
                    else {
                        result = result + tran.translate(String.valueOf(c)).toUpperCase();
                    }
                }
                else {
                    c1 = Character.toLowerCase(l.charAt(i + 1));
                    if (c == 'c' && c1 == 'h'){
                        if (Character.isLowerCase(l.charAt(i))) {
                            result = result + tran.translate("ch");
                        }
                        else {
                            result = result + tran.translate("ch").toUpperCase();
                        }
                        i++;
                    }
                    else {
                        if (Character.isLowerCase(l.charAt(i))) {
                            result = result + tran.translate(String.valueOf(c));
                        }
                        else {
                            result = result + tran.translate(String.valueOf(c)).toUpperCase();
                        }
                    }
                }
            }
            IO.println(result);
        }
        IO.println("\n\nPocet riadkov: " + tran.getSize());
    }
}


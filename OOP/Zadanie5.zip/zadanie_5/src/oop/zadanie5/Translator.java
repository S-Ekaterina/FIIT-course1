package oop.zadanie5;

import java.util.HashMap;
import java.util.Map;

public class Translator {
    private Map<String, String> slovnik;

    public Translator () {
        slovnik = new HashMap<>();
    }

    public void set(String slovo, String preklad) {
        slovnik.put(slovo, preklad);
    }
    public String translate(String slovo){
        return slovnik.get(slovo);
    }
    public boolean canTranslate(String slovo){
        return slovnik.get(slovo) != null;
    }
    public int getSize(){
        return slovnik.size();
    }
}

package oop.zadanie6;

public class ElectronicProduct extends Product implements Discountable{
    public int warrantyMonths;

    ElectronicProduct(String id, String name, double price, int warrantyMonths) {
        super(id, name, price);
        this.warrantyMonths = warrantyMonths;
    }
    public int getWarrantyMonths() {
        return warrantyMonths;
    }
    public void setWarrantyMonths(int warrantyMonths) {
        this.warrantyMonths = warrantyMonths;
    }
    public void applyDiscount(double percentage) {
        if (percentage > 0 && percentage <= 100) {
            double price_per = getPrice() * (1 - percentage / 100);
            setPrice(price_per);
        }
    }
    @Override
    public String toString() {
        return super.toString() +
                ", warranty months = " + warrantyMonths;
    }
}

package oop.zadanie6;

import java.util.HashSet;
import java.util.Set;

public class Warehouse {
    private Set<Product> products = new HashSet<>();

    Warehouse() {

    }
    public void addProduct(Product p) throws ProductAlreadyExistsException {
        for (Product prod : products) {
            if (prod.getId().equals(p.getId())) {
                throw new ProductAlreadyExistsException("Produkt s id " + p.getId() + " už existuje.");
            }
        }
        products.add(p);
    }
    public void removeProduct(String id) throws ProductNotFoundException {
        Product toRemove = null;
        for (Product p : products) {
            if (p.getId().equals(id)) {
                toRemove = p;
                break;
            }
        }
        if (toRemove == null) {
            throw new ProductNotFoundException("Produkt s ID " + id + " neexistuje.");
        }
        products.remove(toRemove);
    }
    public int getProductCount() {
        return products.size();
    }
}

package oop.zadanie6;

public class Main {
    static void main(String[] args) {
        ElectronicProduct ep = new ElectronicProduct("E1", "TV", 500.0, 24);

// Getter a Setter pre warrantyMonths
        int months = ep.getWarrantyMonths();  // → 24
        ep.setWarrantyMonths(36);            // zmení na 36

// Aplikovanie zľavy (z rozhrania Discountable)
        ep.applyDiscount(20);                // → cena sa zníži o 20%
        ep.applyDiscount(0);                 // → ignoruje sa (mimo rozsahu (0, 100>)
        ep.applyDiscount(-5);                // → ignoruje sa
        ep.applyDiscount(105);               // → ignoruje sa
        ep.applyDiscount(100);               // → cena bude 0.0

        IO.println(ep.getPrice());
    }
}

package oop.zadanie4;

public class Main {
    static void main(String[] args) {
        Wallet w = new Wallet(100);
        IO.println(Payer.payByWallet(w,10));    // hodnota 90
        IO.println(Payer.payByWallet(w, -9));   // vynimka -1
        IO.println(Payer.payByWallet(w, 99));   // vynimka -2
    }
}
